cn_git_hash = "51522d5"
cn_git_branch = "release-0.8.0"
cn_version = "0.8.0"
